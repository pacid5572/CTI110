import turtle
wn = turtle.Screen()
wn.bgcolor("blue")
wn.title("Derek & Jessica")

Jessica = turtle.Turtle()
Jessica.color("darkgreen")
Jessica.pensize(3)
Jessica.shape("turtle")


Derek = turtle.Turtle()


for i in [0,1,2,3]:
    Derek.forward(50)
    Derek.left(90)

for i in [0,1,2]:
    Jessica.forward(80)
    Jessica.left(120)
    
    
    
