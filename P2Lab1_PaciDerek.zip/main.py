miles_per_gallon = float(input())
dollars_per_gallon = float(input())

your_value1 = (20 / miles_per_gallon) * dollars_per_gallon
your_value2 = (75 / miles_per_gallon) * dollars_per_gallon
your_value3 = (500 / miles_per_gallon) * dollars_per_gallon
print(f'{your_value1:.2f} {your_value2:.2f} {your_value3:.2f}')

miles_per_gallon = float(input())
dollars_per_gallon = float(input())

your_value1 = (20 / miles_per_gallon) * dollars_per_gallon
your_value2 = (75 / miles_per_gallon) * dollars_per_gallon
your_value3 = (500 / miles_per_gallon) * dollars_per_gallon
print(f'{your_value1:.2f} {your_value2:.2f} {your_value3:.2f}')
