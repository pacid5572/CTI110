num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())

your_value1 = num1 * num2 * num3 * num4 
your_value2 = ((num1 + num2 + num3 + num4) /4)

print(f'{your_value1:.0f} {your_value2:.0f}')
print(f'{your_value1:.3f} {your_value2:.3f}')
