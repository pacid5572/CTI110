# This program calculates and diplays travel expenses
# 10/13/2023
# CTI-110 P2HW1 - Travel Expense
# Derek Paci
#


print('This program calculates and displays travel expense')

print('Enter budget:', end ='')
num1 = int(input())

print('Enter travel destination:', end ='')
num2 = input()

print('How much do you think you will spend on gas?', end ='')
num3 = int(input())

print('Approximately, how much will you need for accomodation/hotel?', end ='')
num4 = int(input())

print('Last, how much do you need for food?', end ='')
num5 = int(input())

print('-------Travel Expenses------')
print('Location:', num2)
print(f'Initial Budget: ${num1:.2f}')
print()

print(f'Fuel: ${num3:.2f}')
print(f'Accomodation: ${num4:.2f}')
print(f'Food: ${num5:.2f}')
print()

print('Total expense:', end ='')
your_value1 = (num3 + num4 + num5)
print(f' ${your_value1:.2f}')
print()

print('Remaining balance:', end ='')
your_value2 = (num1 - your_value1)
print(f' ${your_value2:.2f}')
print()














