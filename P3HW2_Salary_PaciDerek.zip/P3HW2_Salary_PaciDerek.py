#CTI-110
#P3HW2-Salary
#Derek Paci
#10/28/2023
#

over_time = 0
over_time_pay = 0

name = input("Enter employee's name: ")
hours_worked = float(input("Enter number of hours worked: "))
pay_rate = float(input("Enter employee's pay rate: "))

if hours_worked > 40:
    over_time = hours_worked - 40
    over_time_pay = over_time * (pay_rate * 1.5)
    hours_worked = hours_worked - over_time

reg_pay = hours_worked * pay_rate
gross_pay = over_time_pay + reg_pay
hours_worked = hours_worked + over_time


print("----------------------------")
print("Employee name: ", name)
print()
print('Hours Worked','Pay Rate','Overtime','Overtime Pay', 'RegHour Pay','Gross Pay')
print('--------------------------------------------------------------------')
print(f'{hours_worked:<15.2f}{pay_rate:<10.2f}{over_time:<10.2f}{over_time_pay:<10.2f}{reg_pay:<10.2f}{gross_pay:<10.2f}')






